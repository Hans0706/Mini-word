#ifndef WORDCHILD_H
#define WORDCHILD_H

#include <QKeyEvent>
#include <QWidget>
#include"QMdiArea"

#include <cstdlib>
#include <QLabel>
#include <QString>
#include <iostream>

class row{
public:
  char * text;
  int size,maxsize;
  int order;

  row * next;

  row(int ord){
      maxsize=100;
      size =0;
      order=ord;
      text=(char *)calloc(maxsize,sizeof(char));
//      for(int i=0;i<maxsize;i++)
//          text[i]='\0';
      next=nullptr;
  }
  ~row(){free(text);}    //警告：调用析构函数时请确保已将该链节从链表中分离，否则可能导致链表断开

  void newNext(){
      row * cache=next;
      next=new row(order + 1);
      next->next=cache;
      while(cache!=nullptr){
          cache->order+=1;
          cache=cache->next;
      }
  }

  void enlarge(){
      maxsize+=100;
      char * cache = (char *)calloc(maxsize,sizeof(char));
//      for(int i=0;i<maxsize;i++)
//          cache[i]='\0';
      for(int i=0;i<size;i++)
          cache[i]=text[i];
      free(text);
      text = cache;
  }
  void input(const char ch,const int pos){
      if(size==maxsize)
          this->enlarge();
      if(pos!=size)
          for(int i=size;i>pos;i--)
              text[i]=text[i-1];
      text[pos]=ch;
      size++;
      std::cout<<"inputed";

      for(int i=0;i<size;i++)
          std::cout<<text[i];
  }

  QString to_QStr(){
      QString qs;
      char *a=text;
      qs = QString("%1").arg(text);
      return qs;
  }
};

class My_cursor{
public:
    int x,y;    //第x行，第y个字符后面
    row * currentRow;

    void moveup();
    void movedown();
    void moveleft();
    void moveright();

    void input(const char c){
        currentRow->input(c,y);
        y++;
        std::cout<<"input";
    }
    void enter(){
        currentRow->newNext();
        currentRow=currentRow->next;
        y=0;
        x++;
    }

    My_cursor(row * current){
        x=1,y=0;
        currentRow=current;
    }
};

class wordchild:public QWidget
{
    Q_OBJECT
public:
    wordchild();
    void keyPressEvent(QKeyEvent *e);
    void paintEvent(QPaintEvent *e);
    void newFile();
    void insert(char s);

    My_cursor * cur;
    row * rowHead;

    QString userFriendlyCurrentFile();
    QString currentFile()  
    {
        return curFile;
    }
protected:
void closeEvent(QCloseEvent *event);    //关闭事件

private:
QString strippedName(const QString &fullFileName);
                                        //获取较短的绝对路径
QString curFile;                        //用于保存当前文件路径
bool isUntitled;                        //作为当前文件是否被保存到硬盘上的标志
};

#endif // WORDCHILD_H














