#include"wordchild.h"
#include<QtWidgets>
#include <QPainter>
#include <QKeyEvent>
#include <QString>

char K[200];

 wordchild::wordchild()
{


     QKeyEvent *e;
     QPaintEvent *event; rowHead = new row(1);
     cur = new My_cursor(rowHead);

//     char * see = rowHead->text;
    setAttribute(Qt::WA_DeleteOnClose);
    setFocusPolicy(Qt::StrongFocus);
    keyPressEvent(e);
    paintEvent(event);
    isUntitled=true;
    setMinimumHeight(300);
    setMinimumWidth(500);

}

void wordchild::newFile()
{
    //设置窗口编号 因为编号会一直被保存 所以需要使用静态变量
    static int sequenceNumber=1;
    //新建的文档默认未命名
    isUntitled=true;
    //将当前文件命名为“文档+编号”的形式 编号先使用再加一
    curFile=tr("文档%1").arg(sequenceNumber++);
}

void wordchild::insert(const char s)
{
    cur->input(s);

//    for(;i<200;i++)
//    {
//        if(K[i]==0)
//            K[i]=s;
//    }
}
void wordchild::closeEvent(QCloseEvent *event)
{
    event->accept();
}


void wordchild::keyPressEvent(QKeyEvent *e)
{


        switch(e->key())

        {
        case Qt::Key_A:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('a');
            else
                this->insert('A');
        case Qt::Key_B:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('b');
            else
                this->insert('B');
        case Qt::Key_C:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('c');
            else
                this->insert('C');
        case Qt::Key_D:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('d');
            else
                this->insert('D');
        case Qt::Key_E:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('e');
            else
                this->insert('E');
        case Qt::Key_F:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('f');
            else
                this->insert('F');
        case Qt::Key_G:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('g');
            else
                this->insert('G');
        case Qt::Key_H:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('h');
            else
                this->insert('H');
        case Qt::Key_I:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('i');
            else
                this->insert('I');
        case Qt::Key_J:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('j');
            else
                this->insert('J');
        case Qt::Key_K:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('k');
            else
                this->insert('K');
        case Qt::Key_L:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('l');
            else
                this->insert('L');
        case Qt::Key_M:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('m');
            else
                this->insert('M');
        case Qt::Key_N:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('n');
            else
                this->insert('N');
        case Qt::Key_O:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('o');
            else
                this->insert('O');
        case Qt::Key_P:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('p');
            else
                this->insert('P');
        case Qt::Key_Q:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('q');
            else
                this->insert('Q');
        case Qt::Key_R:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('r');
            else
                this->insert('R');
        case Qt::Key_S:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('s');
            else
                this->insert('S');
        case Qt::Key_T:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('t');
            else
                this->insert('T');
        case Qt::Key_U:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('u');
            else
                this->insert('U');
        case Qt::Key_V:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('v');
            else
                this->insert('V');
        case Qt::Key_W:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('w');
            else
                this->insert('W');
        case Qt::Key_X:if(LOBYTE(GetKeyState(VK_CAPITAL))==00)
                this->insert('x');
            else
                this->insert('X');
        case Qt::Key_Y:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('y');
            else
                this->insert('Y');
        case Qt::Key_Z:if(LOBYTE(GetKeyState(VK_CAPITAL))==0)
                this->insert('z');
            else
                this->insert('Z');

    }
update();
}

void wordchild::paintEvent(QPaintEvent *e)
{
    Q_UNUSED(e);
    QPainter painter(this);
//    painter.setRenderHint(QPainter::Antialiasing);
//QString str;
//        str=QString(QLatin1String(K));


//        painter.drawText(20, 20, str);

//    std::string data0 = rowHead->toStr();
    QString str = rowHead->to_QStr();

    QLabel *pLabel = new QLabel(this);
    pLabel->setAlignment(Qt::AlignBottom);
    QFont ft;
    ft.setPointSize(12);
    pLabel->setFont(ft);
    QPalette pa;
    pa.setColor(QPalette::WindowText,Qt::red);
    pLabel->setPalette(pa);
    pLabel->setText(str);
}

